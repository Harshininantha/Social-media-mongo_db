# Social-Media-Backend
Core functionalities of a Social Media App or Website created using Node.js, Express.js and MongoDB as database.

[![Run in Postman](https://run.pstmn.io/button.svg)](https://app.getpostman.com/run-collection/83317d4de8f5e0861f0c?action=collection%2Fimport)
